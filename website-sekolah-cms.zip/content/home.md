---
title: Selamat Datang di Sekolah Kami
subtitle: Sekolah Unggul Berbasis Teknologi dan Karakter
image: /images/uploads/banner.jpg
---