---
vision: Menjadi sekolah unggul dalam prestasi dan berakhlak mulia.
mission:
  - Meningkatkan kualitas pembelajaran.
  - Membangun karakter peserta didik.
  - Mengembangkan teknologi dalam pendidikan.
---